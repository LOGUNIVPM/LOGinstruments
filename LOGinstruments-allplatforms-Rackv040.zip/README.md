# LOGinstruments
LOGinstruments: VCV Rack plugins by Leonardo Gabrielli. For Rack v0.4.0
l.gabrielli@univpm.it
v1.0
